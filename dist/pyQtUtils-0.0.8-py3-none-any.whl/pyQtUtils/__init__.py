from .pyQt_FSlider import FSlider, FSlider_win, setFSlider
